//
//  MOBFJSTypeDefine.h
//  MOBFoundation
//
//  Created by 冯 鸿杰 on 15/2/27.
//  Copyright (c) 2015年 MOB. All rights reserved.
//

#ifndef MOBFoundation_MOBFJSTypeDefine_h
#define MOBFoundation_MOBFJSTypeDefine_h

/**
 *  JS方法实现
 *
 *  @param params 传入参数
 */
typedef void(^MOBFJSMethodIMP) (NSArray *arguments);

#endif
